#include<stdio.h>
#include<conio.h>
#define P printf
#define S scanf

void  main()
{
 int r,c;
 clrscr();

 for(r=5;r>=1;r--)
   {
    for(c=5;c>=r;c--)
       {
	P("%d ",r);
	}
    P("\n");
    }

   getch();
   }