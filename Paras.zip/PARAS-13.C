#include<stdio.h>
#include<conio.h>
#define P printf
#define S scanf

void  main()
{
 int r,c,k;
 clrscr();

 for(r=1;r<=5;r++)
   {
    for(k=1;k<r;k++)
       {
	P("  ");
	}
    for(c=r;c<=5;c++)
       {
	P("%d ",c);
	}
    P("\n");
    }

   getch();
   }