#include<stdio.h>
#include<conio.h>
#define P printf
#define S scanf

void  main()
{
 int r,c;
 clrscr();

 for(r=1;r<=5;r++)
   {
    for(c=r;c>=1;c--)
       {
	P("%d ",c);
	}
    P("\n");
    }
for(r=2;r<=5;r++)
   {
    for(c=6-r;c>=1;c--)
       {
	 P("%d ",c);
	 }
    P("\n");
    }

    getch();
    }


