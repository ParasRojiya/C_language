#include<stdio.h>
#include<conio.h>
#define P printf
#define S scanf

void main()
{
 int r,c;
 clrscr();

 for(r=65;r<=69;r++)
    {
     for(c=65;c<=r;c++)
	{
	 P("%c ",r);
	 }
     P("\n");
     }
 getch();
 }