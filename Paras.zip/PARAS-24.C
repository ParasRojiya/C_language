#include<stdio.h>
#include<conio.h>
#define P printf
#define S scanf

void main()
{
int r,c,k,l;
clrscr();

for(r=1;r<=5;r++)
   {
     for(k=1;k<6-r;k++)
	{
	 P("  ");
	 }
     for(c=5;c>=6-r;c--)
       {
	P("%d ",c);
       }
     for(c=7-r;c<=5;c++)
       {
	P("%d ",c);
	}
     P("\n");
     }

  getch();
  }

