#include<stdio.h>
#include<conio.h>
#define P printf
#define S scanf

void  main()
{
 int r,c;
 clrscr();

 for(r=45;r<=49;r++)
   {
    for(c=45;c<=r;c++)
       {
	P("%d ",c);
	}
    P("\n");
    }

   getch();
   }