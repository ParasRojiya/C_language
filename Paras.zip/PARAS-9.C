#include<stdio.h>
#include<conio.h>
#define P printf
#define S scanf

void  main()
{
 int r,c;
 clrscr();

 for(r=1;r<=5;r++)
   {
    for(c=1;c<=r;c++)
       {
	P("%d ",r);
	}
    P("\n");
    }

   getch();
   }